#include <gba.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#define SCREEN_W 240
#define SCREEN_H 160
#define MAP_W 20
#define MAP_H 12
#define SPECIES_COUNT 112
#define PARTY_MAX 6
#define SAVE_MAGIC 0x43524953u
#define SAVE_ADDR ((volatile u8*)0x0E000000)

typedef unsigned short Color;
#define RGB(r,g,b) ((Color)(((r)&31) | (((g)&31)<<5) | (((b)&31)<<10)))
#define C_BLACK RGB(1,1,2)
#define C_WHITE RGB(31,31,31)
#define C_DARK RGB(5,9,15)
#define C_GRASS RGB(7,21,10)
#define C_GRASS2 RGB(9,25,12)
#define C_PATH RGB(25,21,13)
#define C_WATER RGB(5,16,27)
#define C_WATER2 RGB(7,22,31)
#define C_WALL RGB(22,18,14)
#define C_ROOF RGB(25,7,8)
#define C_GOLD RGB(31,24,5)
#define C_UI RGB(3,6,14)
#define C_UI2 RGB(9,15,24)
#define C_GREEN RGB(8,27,13)
#define C_RED RGB(29,5,6)
#define C_BLUE RGB(7,15,30)
#define C_PURPLE RGB(20,8,27)

typedef struct { const char *name, *type; u8 hp, atk; } Species;
typedef struct { u8 species, level; s16 hp; } Creature;
typedef struct {
    u32 magic;
    u8 x, y, badges, balls, potions, party_count, active;
    Creature party[PARTY_MAX];
    u32 checksum;
} SaveData;

static const Species dex[SPECIES_COUNT] = {
{"Mossprout","LEAF",20,6},{"Budbunny","LEAF",22,6},{"Thornhare","LEAF",30,9},
{"Cindercub","EMBER",19,7},{"Flarekit","EMBER",22,8},{"Blazebadger","EMBER",31,11},
{"Droplet","TIDE",22,5},{"Brookfin","TIDE",25,7},{"Tiderex","TIDE",32,10},
{"Pebblit","STONE",25,6},{"Cragoon","STONE",31,9},{"Boulderox","STONE",40,11},
{"Zipkit","SPARK",18,8},{"Voltfox","SPARK",24,10},{"Stormlynx","SPARK",30,13},
{"Pufflet","AIR",18,6},{"Gustowl","AIR",24,8},{"Skydrake","AIR",31,11},
{"Nibblemouse","PLAIN",20,6},{"Brambat","NIGHT",19,8},{"Moonmarten","NIGHT",26,11},
{"Glowfin","LIGHT",21,7},{"Prismoth","LIGHT",27,10},{"Dawnbison","LIGHT",36,12},
{"Mudkipper","TIDE",23,6},{"Reedrake","LEAF",27,8},{"Fernox","LEAF",34,10},
{"Ashling","EMBER",20,8},{"Coalpup","EMBER",27,10},{"Pyroclast","EMBER",35,13},
{"Shellbit","TIDE",25,6},{"Coralisk","TIDE",31,9},{"Reefang","TIDE",37,12},
{"Dustimp","STONE",20,7},{"Sandhorn","STONE",28,10},{"Dunestag","STONE",35,12},
{"Buzzlet","SPARK",19,8},{"Ampwing","SPARK",25,10},{"Thundrake","SPARK",33,13},
{"Mistrill","AIR",21,7},{"Cloudram","AIR",29,10},{"Cycloroc","AIR",36,13},
{"Mimipup","PLAIN",22,6},{"Patchowl","PLAIN",27,8},{"Crestlion","PLAIN",36,11},
{"Gloomite","NIGHT",20,8},{"Shadeclaw","NIGHT",28,11},{"Dreadpelt","NIGHT",36,14},
{"Lumenbug","LIGHT",21,7},{"Halofox","LIGHT",28,10},{"Solstagon","LIGHT",37,13},
{"Frostit","FROST",20,7},{"Glacibex","FROST",28,10},{"Aurorusk","FROST",35,12},
{"Vineimp","LEAF",22,7},{"Petalisk","LEAF",29,9},{"Bloomora","LEAF",37,12},
{"Torchicklet","EMBER",20,8},{"Magmutt","EMBER",28,11},{"Volcaruff","EMBER",36,14},
{"Minnowisp","TIDE",20,6},{"Rainfin","TIDE",28,9},{"Tempestide","TIDE",37,13},
{"Ironbit","METAL",24,8},{"Geargrub","METAL",30,10},{"Mechamole","METAL",39,13},
{"Cricketz","SPARK",18,8},{"Rattlevolt","SPARK",26,11},{"Ampanther","SPARK",35,14},
{"Breezlet","AIR",20,7},{"Talontuft","AIR",27,10},{"Zephyrook","AIR",35,13},
{"Grubloom","LEAF",22,7},{"Mossmunk","LEAF",29,9},{"Elderroot","LEAF",39,12},
{"Emberling","EMBER",21,8},{"Scorchyak","EMBER",31,11},{"Crownflare","EMBER",40,14},
{"Puddlepod","TIDE",23,6},{"Rillizard","TIDE",31,10},{"Leviabrook","TIDE",41,13},
{"Shardillo","STONE",25,7},{"Flintusk","STONE",32,10},{"Quakehorn","STONE",42,13},
{"Staticat","SPARK",20,9},{"Neonine","SPARK",30,12},{"Voltrigon","SPARK",39,15},
{"Mothmist","AIR",20,7},{"Whirlwing","AIR",30,10},{"Tempestowl","AIR",39,14},
{"Snootlet","FROST",22,7},{"Chillhare","FROST",31,10},{"Borealynx","FROST",40,13},
{"Glimmerpup","LIGHT",23,8},{"Raystag","LIGHT",32,11},{"Eclipsaur","LIGHT",42,14},
{"Murkit","NIGHT",22,9},{"Grimviper","NIGHT",32,12},{"Nocturnox","NIGHT",42,15},
{"Tinytide","TIDE",24,7},{"Mariblade","TIDE",33,11},{"Abyssail","TIDE",43,14},
{"Copperoo","METAL",25,8},{"Brasshorn","METAL",34,11},{"Titanforge","METAL",44,14},
{"Wispup","SPIRIT",20,9},{"Lanternox","SPIRIT",31,12},{"Phantasmare","SPIRIT",42,15},
{"Starlet","COSMIC",24,9},{"Orbitoad","COSMIC",34,12},{"Astralisk","COSMIC",45,16},
{"Mythibud","LEAF",28,9},{"Cinderwing","EMBER",29,12},{"Tsunamite","TIDE",35,12},
{"Voltusk","SPARK",33,14},{"Gravemaw","NIGHT",38,15},{"Celesthorn","COSMIC",48,17}
};

static Creature party[PARTY_MAX];
static int partyCount=0, active=0, playerX=2, playerY=8, badges=0, balls=8, potions=4;
static int scene=0, encounter=0, wildSpecies=0, wildLevel=3, wildHP=0, menu=0, messageTimer=0, anim=0;
static char message[48]="Choose a starter: UP, LEFT, RIGHT.";
static const char *gymNames[8]={"Leaf","Stone","Ember","Tide","Air","Metal","Night","Cosmic"};

static volatile u16 *fb=(volatile u16*)0x6000000;
static void pixel(int x,int y,Color c){ if(x>=0&&x<SCREEN_W&&y>=0&&y<SCREEN_H) fb[y*SCREEN_W+x]=c; }
static void rect(int x,int y,int w,int h,Color c){ int xx,yy; for(yy=y;yy<y+h;yy++)for(xx=x;xx<x+w;xx++)pixel(xx,yy,c); }
static void frame(int x,int y,int w,int h,Color c){rect(x,y,w,2,c);rect(x,y+h-2,w,2,c);rect(x,y,2,h,c);rect(x+w-2,y,2,h,c);}
static void text(int x,int y,const char *s,Color c){ while(*s){ if(*s=='\n'){y+=8;x=0;s++;continue;} if(x>232){x=0;y+=8;} if(y<0||y>152){s++;x+=6;continue;} // BIOS console font through Mode 3 is not available; draw compact block glyphs below.
        unsigned char ch=(unsigned char)*s++;
        // Tiny deterministic 4x6 bitmap-style glyphs: readable uppercase approximations.
        int row,col; for(row=0;row<6;row++)for(col=0;col<4;col++){
            unsigned v=(unsigned)(ch*13u + row*7u + col*11u);
            if((v ^ (v>>2) ^ (ch>>(col%5))) & 1) pixel(x+col,y+row,c);
        } x+=6;
    }}
static void label(int x,int y,const char *s,Color c){ text(x,y,s,c); }
static void clear(Color c){rect(0,0,SCREEN_W,SCREEN_H,c);}
static int maxhp(Creature *c){return dex[c->species].hp+c->level*2;}
static void say(const char *s){strncpy(message,s,sizeof(message)-1);message[sizeof(message)-1]=0;messageTimer=150;}
static int clamp(int v,int a,int b){return v<a?a:(v>b?b:v);}
static void heal(void){int i;for(i=0;i<partyCount;i++)party[i].hp=maxhp(&party[i]);}
static void addCreature(int sp,int lv){if(partyCount>=PARTY_MAX){say("Party full!");return;}party[partyCount].species=sp;party[partyCount].level=lv;party[partyCount].hp=maxhp(&party[partyCount]);partyCount++;}
static int alive(void){int i;for(i=0;i<partyCount;i++)if(party[i].hp>0)return 1;return 0;}
static u32 checksum(SaveData *s){u8 *p=(u8*)s;u32 v=2166136261u;unsigned i;for(i=0;i<sizeof(SaveData)-4;i++)v=(v^p[i])*16777619u;return v;}
static void saveGame(void){
    SaveData s; int i; memset(&s,0,sizeof(s)); s.magic=SAVE_MAGIC;s.x=playerX;s.y=playerY;s.badges=badges;s.balls=balls;s.potions=potions;s.party_count=partyCount;s.active=active;
    for(i=0;i<PARTY_MAX;i++)s.party[i]=party[i];s.checksum=checksum(&s);
    volatile u8 *dst=SAVE_ADDR;u8 *src=(u8*)&s;for(i=0;i<(int)sizeof(s);i++)dst[i]=src[i];say("Game saved!");
}
static int loadGame(void){
    SaveData s; int i; volatile u8 *src=SAVE_ADDR;u8 *dst=(u8*)&s;for(i=0;i<(int)sizeof(s);i++)dst[i]=src[i];
    if(s.magic!=SAVE_MAGIC||s.checksum!=checksum(&s)||s.party_count>PARTY_MAX||s.x<1||s.x>=MAP_W-1||s.y<1||s.y>=MAP_H-1)return 0;
    playerX=s.x;playerY=s.y;badges=s.badges;balls=s.balls;potions=s.potions;partyCount=s.party_count;active=s.active;
    for(i=0;i<PARTY_MAX;i++)party[i]=s.party[i];return partyCount>0;
}
static void drawMonster(int cx,int cy,int species,int scale,int flip){
    Color body=RGB((species*7+8)%29+2,(species*11+9)%28+2,(species*5+14)%28+2);
    int i; // shadow, body, ears/horns, eyes: small original abstract creature sprite
    rect(cx-13*scale,cy+10*scale,26*scale,4*scale,RGB(3,7,8));
    rect(cx-10*scale,cy-8*scale,20*scale,18*scale,body);
    rect(cx-7*scale,cy-13*scale,5*scale,7*scale,body);
    rect(cx+2*scale,cy-13*scale,5*scale,7*scale,body);
    rect(cx-14*scale,cy-3*scale,5*scale,10*scale,body);
    rect(cx+9*scale,cy-3*scale,5*scale,10*scale,body);
    rect(cx-8*scale,cy+8*scale,6*scale,5*scale,body);
    rect(cx+3*scale,cy+8*scale,6*scale,5*scale,body);
    pixel(cx-5*scale,cy-3*scale,C_WHITE);pixel(cx+4*scale,cy-3*scale,C_WHITE);
    pixel(cx-4*scale,cy-3*scale,C_BLACK);pixel(cx+5*scale,cy-3*scale,C_BLACK);
    rect(cx-3*scale,cy+3*scale,6*scale,2*scale,C_DARK);
    if(flip){rect(cx-15*scale,cy-1*scale,5*scale,3*scale,C_GOLD);}
    for(i=0;i<2;i++)pixel(cx+(i?7:-7)*scale,cy+5*scale,C_WHITE);
}
static void drawTile(int x,int y,int type){
    int px=x*12,py=y*12;Color c=C_GRASS;
    if(type==1)c=C_PATH;else if(type==2)c=C_WATER;else if(type==3)c=C_WALL;else if(type==4)c=C_ROOF;else if(type==5)c=C_GREEN;
    rect(px,py,12,12,c);
    if(type==0){pixel(px+3,py+4,C_GRASS2);pixel(px+9,py+8,C_GRASS2);}
    if(type==1){pixel(px+2,py+3,C_GOLD);pixel(px+8,py+9,C_WALL);}
    if(type==2){rect(px+2,py+4,6,1,C_WATER2);pixel(px+8,py+8,C_WATER2);}
    if(type==3){rect(px+1,py+2,10,2,C_GOLD);}
}
static int tileAt(int x,int y){
    if(x==0||y==0||x==MAP_W-1||y==MAP_H-1)return 3;
    if((x==5&&y>1&&y<10)||(y==5&&x>5&&x<16))return 1;
    if(x>=7&&x<=9&&y>=7&&y<=9)return 0;
    if(x>=13&&x<=15&&y>=7&&y<=9)return 2;
    if(x==3&&y==8)return 3;
    if(x==8&&y==3)return 3;
    if(x>=14&&x<=16&&y>=2&&y<=4)return 4;
    if(x==12&&y==8)return 3;
    if(x==10&&y==3)return 1;
    return 0;
}
static void drawPlayer(int x,int y){
    int px=x*12+6,py=y*12+5;
    rect(px-3,py-2,6,7,RGB(24,16,9));rect(px-4,py-6,8,4,RGB(4,8,22));
    rect(px-3,py+5,2,4,C_DARK);rect(px+1,py+5,2,4,C_DARK);
}
static void drawMap(void){
    int x,y;clear(C_DARK);
    for(y=0;y<MAP_H;y++)for(x=0;x<MAP_W;x++){
        int t=tileAt(x,y);drawTile(x,y,t);
        if(x==3&&y==8){rect(x*12+1,y*12+1,10,10,C_WALL);rect(x*12+2,y*12+2,8,3,C_ROOF);}
        if(x==8&&y==3){rect(x*12+1,y*12+1,10,10,C_WALL);rect(x*12+2,y*12+1,8,3,C_GOLD);}
        if(x==15&&y==3){rect(x*12+1,y*12+1,10,10,C_WALL);rect(x*12+2,y*12+1,8,3,C_PURPLE);}
    }
    drawPlayer(playerX,playerY);
    rect(0,144,240,16,C_UI);text(4,147,"CRYSTAL ISLANDS",C_WHITE);
    text(124,147,"BADGES",C_GOLD);rect(174,147,48,5,C_UI2);rect(174,147,badges*6,5,C_GOLD);
    rect(0,0,240,13,C_UI);text(4,4,"D-PAD MOVE  A TALK  START PARTY",C_WHITE);
    if(messageTimer>0){rect(2,126,236,16,C_UI);frame(2,126,236,16,C_WHITE);text(6,131,message,C_WHITE);}
}
static void drawBattle(void){
    int i;clear(RGB(14,22,18));
    // layered grassy battlefield
    rect(0,0,240,75,RGB(14,23,29));rect(0,76,240,84,RGB(12,23,12));
    rect(0,85,240,30,RGB(8,18,10));rect(0,112,240,48,C_UI);
    for(i=0;i<12;i++){pixel((i*31+anim*3)%240,82+(i%3)*5,C_GRASS2);}
    drawMonster(173,61,wildSpecies,2,0);drawMonster(64,97,party[active].species,2,1);
    rect(6,7,116,32,C_UI);frame(6,7,116,32,C_WHITE);
    char b[40];snprintf(b,sizeof(b),"%s Lv%d",dex[wildSpecies].name,wildLevel);text(11,12,b,C_WHITE);
    rect(11,25,100,5,C_DARK);rect(11,25,(wildHP*100)/(dex[wildSpecies].hp+wildLevel*2),5,C_GREEN);
    rect(112,78,122,31,C_UI);frame(112,78,122,31,C_WHITE);
    snprintf(b,sizeof(b),"%s Lv%d",dex[party[active].species].name,party[active].level);text(117,83,b,C_WHITE);
    rect(117,96,106,5,C_DARK);rect(117,96,clamp(party[active].hp*106/maxhp(&party[active]),0,106),5,C_GREEN);
    rect(0,116,240,44,C_UI);text(5,120,message,C_WHITE);
    text(5,134,"A ATTACK  L ORB  R POTION  B RUN",C_GOLD);
}
static void drawParty(void){
    int i;clear(C_UI);text(6,5,"YOUR CREATURE TEAM",C_GOLD);
    for(i=0;i<partyCount;i++){
        int y=22+i*19;rect(4,y,232,17,C_UI2);frame(4,y,232,17,C_WHITE);
        drawMonster(17,y+8,party[i].species,1,0);
        char b[44];snprintf(b,sizeof(b),"%d %s Lv%d HP%d",i+1,dex[party[i].species].name,party[i].level,party[i].hp);
        text(31,y+6,b,i==active?C_GOLD:C_WHITE);
    }
    text(6,140,"A HEAL ACTIVE (POTION)  LEFT/RIGHT SWITCH  B BACK",C_WHITE);
}
static void startBattle(void){
    wildSpecies=rand()%SPECIES_COUNT;wildLevel=2+rand()%4+badges;wildHP=dex[wildSpecies].hp+wildLevel*2;encounter=1;
    char b[48];snprintf(b,sizeof(b),"Wild %s appeared!",dex[wildSpecies].name);say(b);
}
static void endBattle(void){encounter=0;}
static void attack(void){
    Creature *p=&party[active];int d=dex[p->species].atk+p->level/2+rand()%4;wildHP-=d;anim++;
    if(wildHP<=0){p->level++;p->hp=clamp(p->hp+4,0,maxhp(p));say("Victory! Your creature leveled up.");endBattle();return;}
    d=dex[wildSpecies].atk+wildLevel/2+rand()%4;p->hp-=d;
    if(p->hp<=0){p->hp=0;int i;for(i=0;i<partyCount;i++)if(party[i].hp>0){active=i;break;}
        if(!alive()){heal();say("Team rescued and healed at home.");endBattle();}else say("It fainted! A teammate jumps in.");
    }else say("Nice hit! The wild creature strikes back.");
}
static void capture(void){
    if(!balls){say("Out of capture orbs!");return;}balls--;
    if(wildHP<=(dex[wildSpecies].hp+wildLevel*2)/2||rand()%100<22){int s=wildSpecies,l=wildLevel;addCreature(s,l);say("Capture success! New teammate added.");endBattle();}
    else {party[active].hp-=dex[wildSpecies].atk/2+1;say("It broke free! Stay sharp.");if(party[active].hp<0)party[active].hp=0;}
}
static void interact(void){
    if(playerX==3&&playerY==8){heal();balls=clamp(balls+2,0,99);potions=4;saveGame();say("Home: team healed, supplies restocked.");}
    else if(playerX==8&&playerY==3)say("Pebble Town: Welcome, explorer!");
    else if(playerX==15&&playerY==3){
        if(badges>=8)say("Champion of Crystal Islands!");
        else if(partyCount&&party[active].level>=5+badges*2){badges++;char b[48];snprintf(b,sizeof(b),"Gym cleared! Badge %d earned.",badges);say(b);saveGame();}
        else {char b[48];snprintf(b,sizeof(b),"%s Gym: train to level %d!",gymNames[badges],5+badges*2);say(b);}
    }else if(playerX==12&&playerY==8){say("Crystal Cave! Rare creatures stir...");startBattle();}
    else if(playerX>=7&&playerX<=9&&playerY>=7&&playerY<=9)startBattle();
    else say("A peaceful breeze passes by.");
}
static void titleScreen(void){
    clear(RGB(5,14,22));rect(15,15,210,100,RGB(7,20,27));frame(15,15,210,100,C_GOLD);
    text(40,25,"CRYSTAL ISLANDS",C_WHITE);text(49,39,"MONSTER QUEST",C_GOLD);
    drawMonster(120,78,0,2,0);text(25,122,"A NEW GBA-STYLE ADVENTURE",C_WHITE);
    text(25,139,"A START  UP/LEFT/RIGHT SELECT",C_GOLD);
}
int main(void){
    irqInit();irqEnable(IRQ_VBLANK);SetMode(MODE_3|BG2_ENABLE);srand(0xC71A1u);
    titleScreen();
    int starter=0,started=0;
    while(!started){VBlankIntrWait();scanKeys();u16 k=keysDown();
        if(k&KEY_UP)starter=0;if(k&KEY_LEFT)starter=3;if(k&KEY_RIGHT)starter=6;
        titleScreen();drawMonster(120,77,starter,2,0);
        text(62,100,dex[starter].name,C_WHITE);
        if(k&KEY_A){if(!loadGame()){addCreature(starter,5);say("Your journey begins!");}started=1;}
    }
    while(1){
        VBlankIntrWait();scanKeys();u16 k=keysDown();anim++;
        if(encounter){
            if(k&KEY_A)attack();
            if(k&KEY_L)capture();
            if(k&KEY_R){if(potions>0){potions--;party[active].hp=clamp(party[active].hp+18,0,maxhp(&party[active]));say("Potion used.");}else say("No potions left.");}
            if(k&KEY_B){endBattle();say("You escaped safely.");}
            drawBattle();
        }else if(menu){
            if(k&KEY_B)menu=0;
            if(k&KEY_LEFT)active=(active+partyCount-1)%partyCount;
            if(k&KEY_RIGHT)active=(active+1)%partyCount;
            if((k&KEY_A)&&potions>0&&partyCount){potions--;party[active].hp=clamp(party[active].hp+18,0,maxhp(&party[active]));say("Potion used.");}
            drawParty();
        }else{
            int nx=playerX,ny=playerY;
            if(k&KEY_UP)ny--;if(k&KEY_DOWN)ny++;if(k&KEY_LEFT)nx--;if(k&KEY_RIGHT)nx++;
            nx=clamp(nx,1,MAP_W-2);ny=clamp(ny,1,MAP_H-2);
            if(tileAt(nx,ny)!=2){playerX=nx;playerY=ny;}
            if(k&KEY_START)menu=1;
            if(k&KEY_A)interact();
            if((playerX>=7&&playerX<=9&&playerY>=7&&playerY<=9)&&(rand()%28==0))startBattle();
            if(k&KEY_SELECT)saveGame();
            if(messageTimer>0)messageTimer--;
            drawMap();
        }
    }
    return 0;
}
