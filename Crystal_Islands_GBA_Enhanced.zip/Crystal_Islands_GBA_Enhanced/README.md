# Crystal Islands — Enhanced GBA RPG

Original, Pokémon-inspired monster-catching adventure for Game Boy Advance emulators.
All creature names are original. No official Pokémon names, sprites, maps, music, or other
copyrighted game assets are included.

## What's new in this update
- Mode 3 pixel-art rendering for a colorful GBA-style screen
- Original procedurally colored creature sprites, battle scene, player sprite, terrain tiles
- Small overworld with grass, water, home, town, gym, and cave landmarks
- Animated battle field accents
- Party screen and creature switching
- SRAM save/load support (SELECT saves; interacting at home also saves)
- 112 original creatures, capture orbs, potions, leveling, and eight gym challenges

## Build a real `.gba` ROM
A precompiled ROM is not included because the GBA compiler is not installed in this environment.
Build this source with devkitPro/devkitARM and libgba.

1. Install devkitPro: https://devkitpro.org/wiki/Getting_Started
2. Install the `gba-dev` group and libgba through devkitPro pacman.
3. Extract this folder and open a terminal in it.
4. Run `make`.
5. Load `crystal_islands.gba` in mGBA or another GBA emulator.

## Controls
- D-pad: move / navigate
- A: choose starter, interact, attack, or use potion in party screen
- L: throw capture orb during battle
- R: use potion during battle
- B: run from battle / close party screen
- START: open party screen
- SELECT: save game
- At home (H): heal your team, restock supplies, and save

## Important technical note
The GBA has a 240x160 display. This prototype uses Mode 3 bitmap rendering and draws simple
original pixel-art-like sprites directly in C, rather than loading a full commercial-style
tile/sprite asset pipeline. Text is rendered using a tiny built-in procedural glyph approximation
to keep this prototype self-contained. The next step for a polished game is to replace these
placeholders with hand-authored 4bpp tiles/sprites, add sound, collision-aware maps, proper
trainer battle logic, and a tested save backend.
